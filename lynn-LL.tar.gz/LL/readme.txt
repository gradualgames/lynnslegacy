- Lynn's Legacy -
Private Beta (chapter one demo)

Controls:
Arrow keys ---- Move character.
Ctrl key ------ Attack.
Alt key ------- Use secondary item.
Space key ----- Use/talk/confirm.
Esc key ------- Bring up in-game menu.
Enter key ----- Confirm.
< and > ------- 'Quick switch' secondary item.

The white 'S' in a circle is a save point. Walk onto it, and when it changes colors, press space to access the save dialog. Select a slot and press enter to save your game, and Esc to exit the dialog.

This demo plays up to the end of the third dungeon. (end of chapter one) Please report any bugs, crashes, or even spelling errors or complaints about difficulty/balance to:
rubentbstk@aol.com

Your time is much appreciated.

	~ Josiah Tobin and Cha0s, LL team







Compilation Information:

source for the applications used to create ll can be found in src\


src\headers = header files
src\com = shared source files

src\ll = ll.exe
src\replacer = replacer.exe
src\map_conv = converter.exe
src\gmap = gmap.exe


you need GNU make to make the applications. either set the path to your fbc global, 
or change the path in the makefile to your fbc path.
